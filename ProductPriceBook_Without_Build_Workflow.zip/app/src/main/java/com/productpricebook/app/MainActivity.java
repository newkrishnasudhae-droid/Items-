package com.productpricebook.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    ArrayList<Product> products = new ArrayList<>();
    ProductAdapter adapter;
    EditText search;
    android.content.SharedPreferences prefs;
    final String KEY="products";

    String[] units={"পিস","কেজি","গ্রাম","বস্তা","টিন","লিটার","মিলিলিটার","স্কয়ার ফুট","স্কয়ার মিটার",
            "ফুট","মিটার","ইঞ্চি","সেন্টিমিটার","বান্ডিল","প্যাকেট","বাক্স","সেট","জোড়া","রোল","কার্টন",
            "ডজন","ট্রাক","লোড","কুইন্টাল","ঘনফুট (CFT)","অন্যান্য"};

    ActivityResultLauncher<String> createBackup = registerForActivityResult(
        new ActivityResultContracts.CreateDocument("application/json"), uri -> {
            if(uri!=null) writeBackup(uri);
        });
    ActivityResultLauncher<String[]> openBackup = registerForActivityResult(
        new ActivityResultContracts.OpenDocument(), uri -> {
            if(uri!=null) readBackup(uri);
        });

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("data",MODE_PRIVATE);
        load();
        RecyclerView rv=findViewById(R.id.list);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter=new ProductAdapter(products);
        rv.setAdapter(adapter);
        search=findViewById(R.id.search);
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ adapter.filter(s.toString());}
            public void afterTextChanged(android.text.Editable e){}
        });
        findViewById(R.id.addBtn).setOnClickListener(v->showProductDialog(-1));
        findViewById(R.id.backupBtn).setOnClickListener(v->createBackup.launch("ProductPriceBook_Backup.json"));
        findViewById(R.id.restoreBtn).setOnClickListener(v->openBackup.launch(new String[]{"application/json","text/*"}));
    }

    void showProductDialog(int pos){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,5,30,5);
        EditText name=new EditText(this); name.setHint("Product Name");
        EditText price=new EditText(this); price.setHint("Price"); price.setInputType(2|8192);
        Spinner unit=new Spinner(this); unit.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,units));
        EditText category=new EditText(this); category.setHint("Category");
        EditText usage=new EditText(this); usage.setHint("Usage / ব্যবহার");
        box.addView(name); box.addView(price); box.addView(unit); box.addView(category); box.addView(usage);
        if(pos>=0){
            Product p=products.get(pos); name.setText(p.name); price.setText(p.price);
            category.setText(p.category); usage.setText(p.usage);
            for(int i=0;i<units.length;i++) if(units[i].equals(p.unit)) unit.setSelection(i);
        }
        new AlertDialog.Builder(this).setTitle(pos<0?"Add Product":"Edit Product").setView(box)
            .setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{
                String n=name.getText().toString().trim();
                if(n.isEmpty()){Toast.makeText(this,"Product name required",Toast.LENGTH_SHORT).show();return;}
                Product p=new Product(n,price.getText().toString(),unit.getSelectedItem().toString(),
                    category.getText().toString(),usage.getText().toString());
                if(pos<0) products.add(p); else products.set(pos,p);
                save(); adapter.setData(products);
            }).show();
    }

    void load(){
        products.clear();
        try{
            JSONArray a=new JSONArray(prefs.getString(KEY,"[]"));
            for(int i=0;i<a.length();i++) products.add(Product.from(a.getJSONObject(i)));
        }catch(Exception ignored){}
    }
    void save(){
        JSONArray a=new JSONArray(); for(Product p:products)a.put(p.toJson());
        prefs.edit().putString(KEY,a.toString()).apply();
    }
    void writeBackup(Uri uri){
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            out.write(prefs.getString(KEY,"[]").getBytes("UTF-8"));
            Toast.makeText(this,"Backup saved",Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,"Backup failed",Toast.LENGTH_SHORT).show();}
    }
    void readBackup(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri)){
            BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));
            StringBuilder s=new StringBuilder(); String line; while((line=r.readLine())!=null)s.append(line);
            new JSONArray(s.toString()); prefs.edit().putString(KEY,s.toString()).apply(); load(); adapter.setData(products);
            Toast.makeText(this,"Restore complete",Toast.LENGTH_SHORT).show();
        }catch(Exception e){Toast.makeText(this,"Invalid backup file",Toast.LENGTH_SHORT).show();}
    }

    class Product {
        String name,price,unit,category,usage;
        Product(String n,String p,String u,String c,String us){name=n;price=p;unit=u;category=c;usage=us;}
        JSONObject toJson(){JSONObject o=new JSONObject();try{o.put("name",name);o.put("price",price);o.put("unit",unit);o.put("category",category);o.put("usage",usage);}catch(Exception ignored){}return o;}
        static Product from(JSONObject o){return new Product(o.optString("name"),o.optString("price"),o.optString("unit"),o.optString("category"),o.optString("usage"));}
    }

    class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.H>{
        ArrayList<Product> all,shown;
        ProductAdapter(ArrayList<Product> p){all=p;shown=new ArrayList<>(p);}
        void setData(ArrayList<Product> p){all=p;filter(search==null?"":search.getText().toString());}
        void filter(String q){shown=new ArrayList<>(); q=q.toLowerCase(); for(Product p:all)
            if((p.name+" "+p.unit+" "+p.category+" "+p.usage).toLowerCase().contains(q))shown.add(p);notifyDataSetChanged();}
        public H onCreateViewHolder(android.view.ViewGroup v,int t){return new H(getLayoutInflater().inflate(R.layout.item_product,v,false));}
        public void onBindViewHolder(H h,int i){Product p=shown.get(i);h.name.setText(p.name);h.details.setText("দাম: ₹"+p.price+" / "+p.unit+"   |   "+p.category);h.usage.setText("ব্যবহার: "+p.usage);
            h.edit.setOnClickListener(v->{int x=products.indexOf(p);showProductDialog(x);});
            h.delete.setOnClickListener(v->new AlertDialog.Builder(MainActivity.this).setMessage("Delete "+p.name+"?").setNegativeButton("No",null).setPositiveButton("Yes",(d,w)->{products.remove(p);save();setData(products);}).show());}
        public int getItemCount(){return shown.size();}
        class H extends RecyclerView.ViewHolder{TextView name,details,usage;Button edit,delete;H(View v){super(v);name=v.findViewById(R.id.name);details=v.findViewById(R.id.details);usage=v.findViewById(R.id.usage);edit=v.findViewById(R.id.edit);delete=v.findViewById(R.id.delete);}}
    }
}
